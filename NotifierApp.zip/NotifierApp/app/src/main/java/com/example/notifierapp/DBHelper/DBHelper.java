package com.example.notifierapp.DBHelper;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;

    public class DBHelper extends SQLiteOpenHelper {

    private static final String  DB_Name = "Location.db";
    private static final int DB_VER = 1;
    private static final String  TBL_Name = "Coordinate";
    private static final String  COL_Coordinates = "coordinates";
    private static final String  COL_Image = "image";

    public DBHelper(Context context) {
        super(context, DB_Name, null, DB_VER);
    }


    //save to db
    public void addBitMap(String coordinates, byte[] image){
        //have to floor *** the long and lat (make them int)
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues cv =  new ContentValues();
        cv.put(COL_Coordinates,coordinates);
        cv.put(COL_Image,image);
        database.insert(TBL_Name,null,cv);
    }


       //retrieve from db
        public byte[] getBitMap(String coordinates){
        SQLiteDatabase database = this.getWritableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();
        String[] select  = {COL_Coordinates,COL_Image};
        qb.setTables(TBL_Name);
        Cursor c = qb.query(database,select,"coordinates=?",new String[]{coordinates},null,null,null);
        byte[] result =  null;
        if(c.moveToFirst()) {
            do {
                result = c.getBlob(c.getColumnIndex(COL_Image));
            } while (c.moveToNext());

        }
            return  result;

      }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
