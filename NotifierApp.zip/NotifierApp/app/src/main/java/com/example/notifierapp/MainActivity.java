package com.example.notifierapp;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.example.notifierapp.DBHelper.DBHelper;
import com.example.notifierapp.Utils.Utils;

public class MainActivity extends AppCompatActivity {
    private Button uploadButton;
    private static final int CAMERA_REQUEST_CODE = 200 ;
    private ImageView imageView;
 DBHelper dbHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        uploadButton = (Button)findViewById(R.id.upload);
        imageView = (ImageView)findViewById(R.id.imageView);
        dbHelper = new DBHelper(this);
        uploadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent  = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent,CAMERA_REQUEST_CODE);
            }
        });
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==CAMERA_REQUEST_CODE &&  resultCode == RESULT_OK){
            Bundle extras = data.getExtras();
            Bitmap image = (Bitmap)extras.get("data");
         dbHelper.addBitMap("300.5, 502.6",Utils.getBytes(image));
        }
      byte[]  imgBytes =  dbHelper.getBitMap("300.5, 502.6");
       if(imgBytes !=null){
           Bitmap bitmapImage =  Utils.getImage(imgBytes);
           imageView.setImageBitmap(bitmapImage);
       }

    }

}


